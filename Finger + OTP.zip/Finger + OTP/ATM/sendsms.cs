﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ATM
{
    class sendsms
    {
        public static bool SendSMS(string num, string msg)
        {
            try
            {

                string userName = "aditibane555@gmail.com";
                string Key = "AC51229B-6F59-1FDF-575C-0DE48A63AB85";
                string Number = num;
                string Message = msg;

                //  attempt to send message

                ATM.SMSRespondsData _Data = ATM.ClickSendSMS.SendSms(userName, Key, Number, Message, "", "");

                // load result
                string ResultTo = _Data.SMSTo;
                string ResultMessageId = _Data.Message;
                int ResultCode = _Data.RespondsCode;
                string ResultErrorText = _Data.RespondsText;

                // check result
                if (ResultCode == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;  
            } 

        }
    }
}
